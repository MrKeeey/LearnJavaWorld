package com.example.filesTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilesTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilesTestApplication.class, args);
	}

}
