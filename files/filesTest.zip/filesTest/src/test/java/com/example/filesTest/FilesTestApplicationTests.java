package com.example.filesTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilesTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
